//
// Created by yenkn on 19-3-13.
//

#include "speed_controller.h"

#include <map>

namespace racecar_control {

SpeedController::SpeedController(): interpolator(InterpolateMode::Linear, BoundaryType::Clamp) {
  nodeHandle_ = ros::NodeHandle("~");

  nodeHandle_.param<std::string>("odom", odomTopic_, "/odometry/filtered");
  nodeHandle_.param<std::string>("commander", subTopic_, "/cmd_vel");
  nodeHandle_.param<double>("throttle_max", throttleMax_, 1.0);
  nodeHandle_.param("control_rate", controlRate_, 100);

  int displayRate = 0;
  nodeHandle_.param("display_rate", displayRate, 100);

  nodeHandle_.param("racecar_properties/max_speed", maxSpeed_, 10.0);
  nodeHandle_.param("racecar_properties/max_steering", maxSteering_, 0.7);

  // dsrv_.setCallback(std::bind(&SpeedController::paramCallback, this, std::placeholders::_1, std::placeholders::_2));

  if (!nodeHandle_.getParam("KP", speedKP_) ||
      !nodeHandle_.getParam("KD", speedKD_) ||
      !nodeHandle_.getParam("KI", speedKI_) ||
      !nodeHandle_.getParam("KInterp", speedKInterp_)) {
    ROS_ERROR("Could not get all PID params");
  }

  nodeHandle_.param("openLoop", openLoop_, true);

  loadThrottleMapping();

  odomSub_ = nodeHandle_.subscribe(odomTopic_, 1, &SpeedController::odomCallback, this);
  cmdVelSub_ = nodeHandle_.subscribe(subTopic_, 1, &SpeedController::cmdVelCallback, this);
  speedSub_ = nodeHandle_.subscribe("/speed", 1, &SpeedController::speedCallback, this);
  commandPub_ = nodeHandle_.advertise<racecar_msgs::ChassisCommand>("/controller/chassis_command", 1);

  controlTimer_ = nodeHandle_.createTimer(ros::Rate(controlRate_), &SpeedController::timerCallback, this);
  dispTimer_ = nodeHandle_.createTimer(ros::Rate(displayRate), &SpeedController::displayCallback, this);

  ROS_INFO("PID values: %.6f, %.6f, %.6f", speedKP_, speedKI_, speedKD_);
}

void SpeedController::spin() {
  ros::spin();
}

void SpeedController::paramCallback(racecar_control::speed_controllerConfig &config, uint32_t level) {
  speedKP_ = config.speed_p;
  speedKI_ = config.speed_i;
  speedKD_ = config.speed_d;

  ROS_INFO("PID recived: %.6f, %.6f, %.6f", speedKP_, speedKI_, speedKD_);
}

void SpeedController::odomCallback(const nav_msgs::OdometryConstPtr &odom) {
  // currentSpeed_ = odom->twist.twist.linear.x;
}

void SpeedController::speedCallback(const geometry_msgs::TwistConstPtr &speed) {
  currentSpeed_ = speed->linear.x;
}

void SpeedController::displayCallback(const ros::TimerEvent &) {
  if (std::abs(setSpeed_) > 0.01) {
    ROS_INFO("set: %.2f, current: %.2f, inter: %.2f, throttle: %.8f", setSpeed_, currentSpeed_, interpolator.interpolate(setSpeed_), throttle_);
  }
}

void SpeedController::timerCallback(const ros::TimerEvent &) {
  double dt = ros::Rate(controlRate_).cycleTime().toSec();
  double error = setSpeed_ - currentSpeed_;

  if(openLoop_) {
    double interpolateValue = interpolator.interpolate(setSpeed_);
    throttle_ = interpolateValue * speedKInterp_;
  } else {
    throttle_ += speedKP_ * (error - previousError_) +
                 speedKI_ * error +
                 speedKD_ * (error - previousError_ * 2 + lastPreviousError_);
  }
  throttle_ = std::max(-throttleMax_, std::min(throttleMax_, throttle_));

  lastPreviousError_ = previousError_;
  previousError_ = error;

  sendCommand(throttle_, setSteering_); // invalid steering
}

void SpeedController::cmdVelCallback(const geometry_msgs::TwistConstPtr &twist) {
  if (std::abs(setSpeed_ - twist->linear.x) >= 0.01) {
    ROS_INFO("SpeedController: new speed setPoint:%.2f", twist->linear.x);
  }
  setSpeed_ = twist->linear.x;
  setSteering_ = twist->angular.z / maxSteering_;
}

void SpeedController::sendCommand(double throttle, double steering) {
  racecar_msgs::ChassisCommand command;
  command.header.stamp = ros::Time::now();
  command.sender = "controller";
  command.throttle = std::min(std::max(throttle, -1.0), 1.0);
  command.steering = std::min(std::max(steering, -1.0), 1.0);
  commandPub_.publish(command);
}

void SpeedController::loadThrottleMapping() {
  XmlRpc::XmlRpcValue v;
  nodeHandle_.param("throttle_mapping", v, v);
  std::map<double, double> mapping;
  for(auto &mapIt : v)
  {
    if(mapIt.second.getType() == XmlRpc::XmlRpcValue::TypeDouble)
    {
      std::pair<double, double> toAdd(std::pair<double, double>(
          boost::lexical_cast<double>(mapIt.first),
          static_cast<double>(mapIt.second)));
      mapping[toAdd.first] = toAdd.second;
      ROS_INFO("SpeedController added to add mapping %0.2f : %0.2f", toAdd.first, toAdd.second);
    } else
    {
      ROS_ERROR("SpeedController: XmlRpc throttle calibration formatted incorrectly");
    }
  }
  interpolator.setPoints(mapping);
}

}

int main(int argc, char **argv) {
  ros::init(argc, argv, "speed_controller");
  racecar_control::SpeedController controller;
  controller.spin();
  return 0;
}