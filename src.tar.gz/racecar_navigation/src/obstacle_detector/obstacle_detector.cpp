//
// Created by yenkn on 19-5-16.
//

#include "obstacle_detector/obstacle_detector.h"
#include <racecar_core/utils/tf.h>
#include <racecar_core/utils/laser.h>
#include <racecar_core/utils/std.h>
#include <racecar_core/utils/math.h>
#include <racecar_msgs/Obstacles.h>
#include <nav_msgs/GridCells.h>
#include <visualization_msgs/MarkerArray.h>
#include <assert.h>
#include <costmap_2d/cost_values.h>
#include <opencv2/opencv.hpp>
#include <racecar_core/utils/cv.h>

ObstacleDetector::ObstacleDetector(): privateNode_("~"), detector_("laser_line") {
  mapSub_ = privateNode_.subscribe("/map", 1, &ObstacleDetector::mapCallback, this);
  scanSub_ = privateNode_.subscribe("/scan", 1, &ObstacleDetector::scanCallback, this);

  scanPub_ = privateNode_.advertise<sensor_msgs::LaserScan>("/obstacle_scan", 1);
  obstaclePub_ = privateNode_.advertise<racecar_msgs::Obstacles>("obstacles", 1);
  markerPub_ = privateNode_.advertise<visualization_msgs::MarkerArray>("makers", 1);

  privateNode_.param("line_segment_distance", lineInSegmentDistance_, 0.2);
  privateNode_.param("exclude_threshold", excludeThreshold_, 20);
  privateNode_.param("cluster_tolerance", clusterTolerance_, 0.3);
  privateNode_.param("obstacle_movement_tolerance", obstacleMovementTolerance_, 1.0);
  privateNode_.param("minimal_survival", minimalSurvival_, 5);
  privateNode_.param("maximal_reserve", maximalReserve_, 5);
  privateNode_.param("minimal_points", minimalPoints_, 2);
  privateNode_.param("maximal_radius", maximalRadius_, 1.0);
  privateNode_.param("erode_size", erodeSize_, 3);

  privateNode_.param("include_radius", includeRadius_, 0.10);
  privateNode_.param("exclude_radius", excludeRadius_, 0.50);
  privateNode_.param("min_points", minPoints_, 3);
  privateNode_.param("distance_filter", distanceFilter_, 3.0);

  ROS_INFO("exclude_threshold: %d", excludeThreshold_);
}

void ObstacleDetector::mapCallback(const nav_msgs::OccupancyGridConstPtr &map) {
  mapRecived_ = true;
  map_ = *map;
  mapOrigin_ = Point2D(map_.info.origin.position.x, map_.info.origin.position.y);

  auto mapImage = utils::mapToImage(map_, 0, true);
  cv::Mat element = cv::getStructuringElement(cv::MORPH_RECT,
                                              cv::Size(2 * erodeSize_ + 1, 2 * erodeSize_ + 1),
                                              cv::Point(erodeSize_, erodeSize_));
  cv::Mat dst;
  cv::erode(mapImage, mapImage_, element);
}

void ObstacleDetector::scanCallback(const sensor_msgs::LaserScanConstPtr &scan) {
  if(!mapRecived_) return;
  if(scan_.header.seq == 0) {
    tf::StampedTransform baseToLaser;
    if(!utils::getTFTransform(tfListener_, "base_footprint", scan->header.frame_id, baseToLaser)) {
      ROS_ERROR("Unable to get base to laser transform");
      return;
    }
    laserToBase_ = baseToLaser.inverse();
    scan_ = *scan;
    return;
  }

  tf::StampedTransform mapToCar;
  if(!utils::getTFTransform(tfListener_, "map", scan->header.frame_id, mapToCar)) {
    return;
  }
  mapToCar_ = mapToCar;

  scan_ = *scan;

  auto lines = detector_.processScan(scan);

  sensor_msgs::LaserScan scanMsg;
  scanMsg = scan_;

  odomBelief_ = 0.0;
  std::vector<Point2D> points;
  for(int i = 0; i < scan_.ranges.size(); i++) {
    if(scan_.ranges[i] < scan_.range_min || scan_.ranges[i] >= scan_.range_max) continue;
    auto angle = scan_.angle_min + i * scan_.angle_increment;
    auto point = utils::polarToCartesian(scan_.ranges[i], angle);
    if(point.length() < 0.2 || point.x() < -1.0) { // self
      scanMsg.ranges[i] = INFINITY;
      continue;
    }
    points.emplace_back(point.x(), point.y());

    // tf::Vector3 mapPos = laserToBase_ * carToMap * point;
    for(auto &line: lines) {
      if(utils::distanceToLine(Point2D(point.x(), point.y()), Point2D(line.x1, line.y1), Point2D(line.x2, line.y2)) <= lineInSegmentDistance_) {
        scanMsg.ranges[i] = INFINITY;
        break;
      }
    }
  }

  kdTree_.build(points);
  if(!points.empty()) {
    auto obstacles = clusterPoints();
    for(auto &ob : obstacles) {
      if(ob.mean.x > 0) {
        double r = ob.mean.length();
        double theta = ob.mean.angleDeg();
        if(theta > 5) {
          int rangeIndex = int((ob.mean.angle() - scanMsg.angle_min) / scanMsg.angle_increment);
          for(int i = 0; i < 50; i+=2) {
            scanMsg.ranges[rangeIndex + i] = (float)r;
            if(rangeIndex + i >= scanMsg.ranges.size()) break;
          }
        } else if(theta < -5) {
          int rangeIndex = int((ob.mean.angle() + scanMsg.angle_max) / scanMsg.angle_increment);
          for(int i = 0; i < 50; i+=2) {
            scanMsg.ranges[rangeIndex - i] = (float)r;
            if(rangeIndex - i < 0) break;
          }
        }
      }
    }
  }

  scanPub_.publish(scanMsg);
}

bool ObstacleDetector::isFamiliarObstacle(const cluster &o1, const cluster &o2) {
  return o1.mapMean.distance(o2.mapMean) < obstacleMovementTolerance_;
}

bool ObstacleDetector::evolvePoints(const std::vector<cluster> &newObstacles) {
  // new -> staged -> stable
  bool changed = false;

  if(stageObstacles_.empty()) {
    stageObstacles_ = newObstacles;
    return changed;
  }

  std::vector<int> surviveList(currentIncreamentId_, 0);

  for(auto &obstacle : newObstacles) {
    // find familiar obstacle
    bool foundFamiliar = false;

    // add stable obstacles survive counter
    for(auto &stablePair : stableObstacles_) {
      if(stablePair.second.valid && isFamiliarObstacle(stablePair.second, obstacle)) {
        auto survive = stablePair.second.surviveCounter + 1;
        if(obstacle.belief >= stablePair.second.belief) {
          stablePair.second = obstacle;
        }
        stablePair.second.surviveCounter = survive;
        stablePair.second.dismissCounter = 0;
        surviveList[stablePair.first]++;
        foundFamiliar = true;
        break;
      }
    }
    if(foundFamiliar) continue; // found in stable obstacles

    for(auto iter = stageObstacles_.begin(); iter != stageObstacles_.end(); ) {
      if(isFamiliarObstacle(*iter, obstacle)) {
        auto survive = iter->surviveCounter + 1;
        *iter = obstacle;
        iter->surviveCounter = survive;
        foundFamiliar = true;
        if(iter->surviveCounter == minimalSurvival_) {
          // transfer from stage -> stable
          stableObstacles_[currentIncreamentId_++] = *iter;
          surviveList.push_back(0);
          if(callback_) callback_(&stableObstacles_[currentIncreamentId_-1], ADD);
          iter = stageObstacles_.erase(iter);
          changed = true;
        }
        break;
      }
      iter++;
    }

    if(!foundFamiliar) {
      // new obstacle
      stageObstacles_.push_back(obstacle);
    }
  }

  for(int i = 0; i < surviveList.size(); i++) {
    if(surviveList[i] == 0) {
      stableObstacles_[i].dismissCounter++;
      if(stableObstacles_[i].valid && stableObstacles_[i].dismissCounter == maximalReserve_) {
        stableObstacles_[i].valid = false;
        if(callback_) callback_(&stableObstacles_[i], REMOVE);
        changed = true;
      }
    }
  }

  return changed;
}

std::vector<ObstacleDetector::cluster> ObstacleDetector::getObstacles() {
  std::vector<cluster> stableObstacles;
  for(const auto &pair : stableObstacles_) {
    if(pair.second.valid) {
      stableObstacles.push_back(pair.second);
    }
  }
  return stableObstacles;
}

void ObstacleDetector::processPoints() {
  auto obstacles = clusterPoints();
//  bool obstacleChanged = evolvePoints(obstacles);
//
//  if(!obstacleChanged) return;
//  auto stableObstacles = getObstacles();

  racecar_msgs::Obstacles msg;
  msg.header.frame_id = "laser_link";
  msg.header.stamp = ros::Time::now();
  for(auto &obstacle: obstacles) {
    racecar_msgs::Obstacle omsg;
    omsg.radius = 0.3;
    omsg.mean = obstacle.mean.toPoint();
    omsg.survive = (uint32_t)obstacle.surviveCounter;
    msg.obstacles.push_back(omsg);
  }
  obstaclePub_.publish(msg);

  std::cout << "detected " << obstacles.size() << " obstacles." << std::endl;
  publishObstacles(obstacles);
}

void ObstacleDetector::publishObstacles(const std::vector<cluster> &obstacles) {
  visualization_msgs::MarkerArray arr;

  visualization_msgs::Marker msg;
  msg.header.frame_id = "laser_link";
  msg.ns = "Markers";

  msg.action = visualization_msgs::Marker::DELETEALL;
  arr.markers.push_back(msg);

  msg.action = visualization_msgs::Marker::ADD;
  msg.pose.orientation.w = 1.0;

  msg.type = visualization_msgs::Marker::CYLINDER;

  msg.scale.z = 0.1;

  msg.color.r = 0.0;
  msg.color.g = 1.0;
  msg.color.b = 1.0;
  msg.color.a = 0.8;

  for(int i = 0; i < obstacles.size(); i++) {
    msg.id = i;
    msg.pose.position = obstacles[i].mean.toPoint();
    msg.scale.y = msg.scale.x = 0.3;
    arr.markers.push_back(msg);
  }

  markerPub_.publish(arr);
}

std::vector<ObstacleDetector::cluster> ObstacleDetector::clusterPoints() {
  auto clusters = kdTree_.cluster(0.1, minPoints_);
  auto obstacles = std::vector<ObstacleDetector::cluster>();
  for(auto &pts: clusters) {
    Point2D mean(0, 0);
    for(auto &pt : pts) {
      mean += pt / pts.size();
    }
    if(kdTree_.radiusSearch(mean, includeRadius_).size() == kdTree_.radiusSearch(mean, excludeRadius_).size() && mean.length() < distanceFilter_) {
      ObstacleDetector::cluster o;
      o.points = pts;
      o.mean = mean;
      auto mapPos = mapToCar_.inverse() * tf::Vector3(mean.x, mean.y, 0);
      o.mapMean = Point2D(mapPos.x(), mapPos.y());
      o.valid = true;
      o.belief = 0.0;
      obstacles.push_back(o);
    }
  }
  return obstacles;
}


int main(int argc, char **argv) {
  ros::init(argc, argv, "obstacle_detector");
  ObstacleDetector detector;

  ros::spin();
  return 0;
}