//
// Created by yenkn on 19-7-14.
//

#include <nav_msgs/Path.h>
#include <racecar_msgs/GetCheckline.h>
#include "graph_planner.h"
#include <tinysplinecpp.h>

GraphPlanner::GraphPlanner(): nh_("~") {
  goalSub_ = nh_.subscribe("/move_base_simple/goal", 1, &GraphPlanner::goalCallback, this);
  amclSub_ = nh_.subscribe("/amcl_pose", 1, &GraphPlanner::amclCallback, this);
  checklineClient_ = nh_.serviceClient<racecar_msgs::GetCheckline>("/checkline");

  pathPub_ = nh_.advertise<nav_msgs::Path>("plan", 1);

  nh_.param("uturn_margin", uTurnMargin_, 0.4);
  nh_.param("sample_times", sampleTimes_, 1000);

  getCheckline();
}

void GraphPlanner::goalCallback(const geometry_msgs::PoseStampedConstPtr &msg) {
  tf::poseMsgToTF(msg->pose, goalPose_);

  makePath();
}

void GraphPlanner::amclCallback(const geometry_msgs::PoseWithCovarianceStampedConstPtr &msg) {
  tf::poseMsgToTF(msg->pose.pose, estimatePose_);
}

bool GraphPlanner::getCheckline() {
  racecar_msgs::GetChecklineRequest req;
  racecar_msgs::GetChecklineResponse res;
  if(!checklineClient_.call(req, res)) {
    ROS_ERROR("unable to get checklines");
    return false;
  }
  checkline_.clear();
  for(int i = 0; i < res.checkline.points.size(); i+=2) {
    checkline_.emplace_back(Point2D(res.checkline.points[i].x, res.checkline.points[i].y), Point2D(res.checkline.points[i+1].x, res.checkline.points[i+1].y));
  }
  uturnIndex_ = res.checkline.uturn_index;
  ROS_INFO("got checklines");
  return true;
}

void GraphPlanner::makePath() {
  if(!getCheckline()) {
    ROS_ERROR("no checklines, unable to make path");
    return;
  }
  std::vector<Point2D> path = { Point2D(estimatePose_.getOrigin().x(), estimatePose_.getOrigin().y()) };

  for(int i = 0; i < checkline_.size(); i++) {
    if(i == uturnIndex_ - 1) {
      Point2D prevPt = (checkline_[i].first + checkline_[i].second) / 2;
      Point2D uMiddle = (checkline_[uturnIndex_].first + checkline_[uturnIndex_].second) / 2;
      Point2D nextPt = (checkline_[uturnIndex_+1].first + checkline_[uturnIndex_+1].second) / 2;

      double turnRadius = fabs(nextPt.y - prevPt.y) / 2;
      Point2D center = checkline_[i].second;

      path.emplace_back(prevPt);
      path.emplace_back(center.x + turnRadius, uMiddle.y);
      path.emplace_back(nextPt);

      i = uturnIndex_ + 1;
    } else {
      path.push_back((checkline_[i].first + checkline_[i].second) / 2);
    }
  }

  path.emplace_back(goalPose_.getOrigin().x(), goalPose_.getOrigin().y());

  tinyspline::BSpline spline(path.size(), 2, 2, TS_CLAMPED);
  std::vector<tinyspline::real> ctrlp = spline.controlPoints();
  for(int i = 0; i < path.size(); i++) {
    ctrlp[i*2] = path[i].x;
    ctrlp[i*2+1] = path[i].y;
  }
  spline.setControlPoints(ctrlp);

  nav_msgs::Path msg;
  msg.header.frame_id = "map";
  msg.header.stamp = ros::Time::now();
  for(int i = 0; i <= sampleTimes_; i++) {
    auto res = spline.eval((double)i/sampleTimes_).result();

    geometry_msgs::PoseStamped pose;
    pose.header = msg.header;
    pose.pose.position.x = res[0];
    pose.pose.position.y = res[1];
    pose.pose.orientation.w = 1;
    msg.poses.push_back(pose);
  }
  pathPub_.publish(msg);
}

int main(int argc, char **argv) {
  ros::init(argc, argv, "graph_planner");
  GraphPlanner planner;
  ros::spin();
  return 0;

}