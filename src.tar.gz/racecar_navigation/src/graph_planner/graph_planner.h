//
// Created by yenkn on 19-7-14.
//

#ifndef SRC_GRAPH_PLANNER_H
#define SRC_GRAPH_PLANNER_H

#include <tf/tf.h>
#include <tf/transform_datatypes.h>
#include <ros/ros.h>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <racecar_msgs/Checkline.h>
#include <racecar_core/point.h>

class GraphPlanner {
public:
  GraphPlanner();


private:
  ros::NodeHandle nh_;
  ros::Publisher pathPub_;
  ros::Subscriber amclSub_, goalSub_, obstacleSub_;
  ros::ServiceClient checklineClient_;

  tf::Pose estimatePose_, goalPose_;
  int uturnIndex_ = 0;
  std::vector<std::pair<Point2D, Point2D>> checkline_;

  double uTurnMargin_;
  int sampleTimes_;

  void amclCallback(const geometry_msgs::PoseWithCovarianceStampedConstPtr &msg);
  void goalCallback(const geometry_msgs::PoseStampedConstPtr &msg);
  bool getCheckline();

  void makePath();
};

#endif //SRC_GRAPH_PLANNER_H
