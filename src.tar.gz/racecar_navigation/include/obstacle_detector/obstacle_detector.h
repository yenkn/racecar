//
// Created by yenkn on 19-5-16.
//

#ifndef PROJECT_OBSTACLE_DETECTOR_NODE_H
#define PROJECT_OBSTACLE_DETECTOR_NODE_H

#include <ros/ros.h>
#include <nav_msgs/OccupancyGrid.h>
#include <tf/tf.h>
#include <costmap_2d/costmap_2d.h>
#include <tf/transform_listener.h>
#include <sensor_msgs/LaserScan.h>
#include <sensor_msgs/PointCloud2.h>
#include <nav_msgs/OccupancyGrid.h>
#include <racecar_core/point.h>
#include <racecar_core/utils/kd_tree.h>
#include <pcl_ros/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc.hpp>
#include "laser_line/laser_feature_ros.h"

typedef pcl::PointCloud<pcl::PointXYZ> PointCloud;

class ObstacleDetector {
public:
  ObstacleDetector();

  static const int ADD = 1;
  static const int REMOVE = 2;

  struct cluster {
      int surviveCounter;
      int dismissCounter;
      bool valid;
      std::vector<Point2D> points;
      Point2D mean;
      Point2D mapMean;
      double radius;
      double belief;
  };

  typedef std::function<void(cluster *, int)> callbackFunction;

  void setObstacleCallback(const callbackFunction &callback) {
    callback_ = callback;
  }

  std::vector<cluster> getObstacles();

private:
  ros::NodeHandle privateNode_;
  ros::Publisher markerPub_, obstaclePub_, scanPub_;
  ros::Subscriber scanSub_, mapSub_;
  tf::TransformListener tfListener_;

  callbackFunction callback_;

  bool mapRecived_ = false;

  tf::Transform laserToBase_, mapToCar_;
  nav_msgs::OccupancyGrid map_;
  sensor_msgs::LaserScan scan_;
  costmap_2d::Costmap2D *costmap_ = nullptr;
  cv::Mat mapImage_;
  Point2D mapOrigin_;

  utils::KDTree<Point2D> kdTree_;
  std::vector<cluster> stageObstacles_;
  laser_line::LaserFeatureROS detector_;

  std::map<int, cluster> stableObstacles_;
  int currentIncreamentId_ = 0;

  double lineInSegmentDistance_;
  double clusterTolerance_, obstacleMovementTolerance_, maximalRadius_, odomBelief_;
  int minimalSurvival_, maximalReserve_, excludeThreshold_, minimalPoints_, erodeSize_;

  double includeRadius_, excludeRadius_, distanceFilter_, pathInterval_;
  int minPoints_;

  void scanCallback(const sensor_msgs::LaserScanConstPtr &scan);
  void mapCallback(const nav_msgs::OccupancyGridConstPtr &map);

  bool isFamiliarObstacle(const cluster &o1, const cluster &o2);
  void publishObstacles(const std::vector<cluster> &obstacles);
  void processPoints();
  bool evolvePoints(const std::vector<cluster> &newObstacles);
  std::vector<cluster> clusterPoints();
};

#endif //PROJECT_OBSTACLE_DETECTOR_NODE_H
