import cv2

if __name__ == '__main__':
    src = cv2.imread('mymap.pgm')
    cv2.imwrite('test.pgm', src[src.shape[0]-1000])
